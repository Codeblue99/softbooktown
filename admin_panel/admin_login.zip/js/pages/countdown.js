//[Javascript]

//Project:	Crypto Admin - Responsive Admin Template

$(function () {

  'use strict';
	var clock = $('.clock').FlipClock(3600 * 24 *99, {
		clockFace: 'DailyCounter',
		countdown: true
	}); 

}); // End of use strict


